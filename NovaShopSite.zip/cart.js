let cart = JSON.parse(localStorage.getItem('cart')) || [];

function addToCart(name, price){
  let item = cart.find(p => p.name === name);
  if(item){
    item.qty++;
  } else {
    cart.push({name, price, qty:1});
  }
  localStorage.setItem('cart', JSON.stringify(cart));
  alert(name + " ajouté au panier ✅");
}

function displayCart(){
  let tableBody = document.querySelector('#cartTable tbody');
  if(!tableBody) return;
  tableBody.innerHTML = '';
  let total = 0;
  cart.forEach((item, index)=>{
    let row = `<tr>
      <td>${item.name}</td>
      <td>${item.price}€</td>
      <td>
        <button onclick="changeQty(${index}, -1)">-</button>
        ${item.qty}
        <button onclick="changeQty(${index}, 1)">+</button>
      </td>
      <td>${item.price * item.qty}€</td>
      <td><button onclick="removeItem(${index})">Supprimer</button></td>
    </tr>`;
    tableBody.innerHTML += row;
    total += item.price * item.qty;
  });
  document.getElementById('grandTotal').innerText = "Total: " + total + "€";
}

function changeQty(index, delta){
  cart[index].qty += delta;
  if(cart[index].qty <= 0) cart.splice(index,1);
  localStorage.setItem('cart', JSON.stringify(cart));
  displayCart();
}

function removeItem(index){
  cart.splice(index,1);
  localStorage.setItem('cart', JSON.stringify(cart));
  displayCart();
}

function calculerTotal(){
  return cart.reduce((sum, item)=> sum + item.price * item.qty, 0);
}

document.addEventListener('DOMContentLoaded', displayCart);